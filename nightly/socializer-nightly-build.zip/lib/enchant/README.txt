
This directory contains the plugin DLLs for enchant when installed on
a Microsoft Windows system.

